﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace J97BILLIARD.Data
{
    public class AccountData
    {
        public string userName { get; set; }
        public string passWord { get; set; }
        public string displayName { get; set; }
        public string idStaff { get; set; }
    }
}
